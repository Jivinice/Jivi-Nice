
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Instagram, MessageSquare, FileText } from "lucide-react";
import Link from "next/link";

export default function JiviNiceLanding() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-100 to-white flex flex-col items-center p-6 space-y-6">
      <h1 className="text-3xl font-bold text-purple-800">JiviNice</h1>
      <p className="text-center text-sm text-gray-600">Belleza de Manos y Uñas</p>

      <Card className="w-full max-w-md">
        <CardContent className="flex flex-col items-center space-y-4 p-6">
          <Link href="https://wa.me/56935354429?text=¡Hola!%20Quiero%20agendar%20un%20turno%20en%20JiviNice">
            <Button className="w-full bg-green-500 hover:bg-green-600 text-white">
              <MessageSquare className="mr-2" /> Reservá por WhatsApp
            </Button>
          </Link>

          <Link href="https://chat.openai.com/share/public_JiviNice.pdf" target="_blank">
            <Button className="w-full bg-purple-500 hover:bg-purple-600 text-white">
              <FileText className="mr-2" /> Ver Catálogo PDF
            </Button>
          </Link>

          <Link href="https://www.instagram.com/jivi.nice" target="_blank">
            <Button className="w-full bg-pink-500 hover:bg-pink-600 text-white">
              <Instagram className="mr-2" /> Seguinos en Instagram
            </Button>
          </Link>

          <Link href="https://www.google.com/maps/place/Avenida+Los+Huilliches+2593" target="_blank">
            <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white">
              <MapPin className="mr-2" /> ¿Dónde estamos?
            </Button>
          </Link>
        </CardContent>
      </Card>

      <div id="catalogo" className="w-full max-w-md space-y-4">
        <Card>
          <CardContent className="p-4">
            <h2 className="font-bold text-purple-700">Servicios</h2>
            <ul className="list-disc list-inside text-sm text-gray-700">
              <li>Esmaltado Permanente – Alta duración y diseño simple incluido.</li>
              <li>Kapping – Fortalece tu uña natural sin alargar.</li>
              <li>Soft Gel – Diseño personalizado y único.</li>
              <li>Retiro seguro de esmaltes sin dañar la uña.</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="font-bold text-purple-700">Promociones</h2>
            <ul className="list-disc list-inside text-sm text-gray-700">
              <li><strong>Pack Amigas:</strong> Vienen 3, pagan 2 (no aplica a diseños personalizados).</li>
              <li><strong>¡Quiero dos!:</strong> 50% de descuento en el segundo servicio (el de menor valor).</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-sm text-gray-700">
            <h2 className="font-bold text-purple-700">Medios de pago</h2>
            <p>Efectivo o transferencia bancaria.</p>
            <p className="mt-2 italic text-xs text-gray-500">*Precios válidos para abril y mayo 2025.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
